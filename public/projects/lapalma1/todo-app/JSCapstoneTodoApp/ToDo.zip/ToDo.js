// Base URL for the Todo API
const BASE_URL = "https://mongodb.simplycodingcourses.com/simply/todo/";
const USER_ID = "gussie"; // Replace with your unique user identifier (e.g., johndoe)
const TOKEN = "f5dd5547c1c7714caa00cfdb69d597da7911842a4a7e923b269533edb5078b64"; // Replace with your token from the API Access page if different

// Axios configuration with Authorization header
axios.defaults.headers.common["Authorization"] = `Bearer ${TOKEN}`;

// Utility function to log actions
function logAction(action) {
  // Simple: Log to console
  // console.log(action);
  // Medium: Append to log area
  const log = document.getElementById('log');
  log.textContent += action + '\n';
  // Advanced: Append as paragraph, auto-scroll
}

// Utility function to format date
function formatDate(dateString) {}

// Fetch todos from API
async function fetchTodos() {
  // Simple: Basic GET request
  // const response = await axios.get(`${BASE_URL}${USER_ID}/get`);
  // return response.data;
  // Medium: GET with error handling
  try {
      const response = await axios.get(`${BASE_URL}${USER_ID}/get`);
      return response.data;
  } catch (error) {
      console.error('Error fetching todos:', error);
      return [];
  }
  // Advanced: GET with error handling and user feedback
}

// Add a new todo
async function addTodo(task, dueDate, completed) {
  // Simple: Basic POST request
  // await axios.post(`${BASE_URL}${USER_ID}/post`, { task, dueDate, completed });
  // Medium: POST with error handling
  try {
      await axios.post(`${BASE_URL}${USER_ID}/post`, { task, dueDate, completed });
  } catch (error) {
      console.error('Error adding todo:', error);
  }
  document.getElementById("todoList").addEventListener("click", function(event){
  event.preventDefault()
  // Advanced: POST with error handling, user feedback
  
});
}

// Update a todo
async function updateTodo(todoId, task, dueDate, completed) {
  // Simple: Basic PUT request
  // await axios.put(`${BASE_URL}${USER_ID}/put/${todoId}`, { task, dueDate, completed });
  // Medium: PUT with error handling
  try {
      await axios.put(`${BASE_URL}${USER_ID}/put/${todoId}`, { task, dueDate, completed });
  } catch (error) {
      console.error('Error updating todo:', error);
  }
  // Advanced: PUT with error handling, user feedback
}

// Delete a todo
async function deleteTodo(todoId) {
  // Simple: Basic DELETE request
  // await axios.delete(`${BASE_URL}${USER_ID}/delete/${todoId}`);
  // Medium: DELETE with error handling
  try {
      await axios.delete(`${BASE_URL}${USER_ID}/delete/${todoId}`);
  } catch (error) {
      console.error('Error deleting todo:', error);
  }
  // Advanced: DELETE with error handling, user feedback
}

// Render todo list
function renderTodos(todos) {
  // Simple: Clear and append todos
  // const todoList = document.getElementById('todoList');
  // todoList.innerHTML = '';
  // todos.forEach(todo => {
  //     const li = document.createElement('li');
  //     li.textContent = `${todo.task} - ${formatDate(todo.dueDate)}`;
  //     todoList.appendChild(li);
  // });
  // Medium: Add buttons but no edit functionality
  const todoList = document.getElementById('todoList');
  todoList.innerHTML = '';
  todos.forEach(todo => {
      const li = document.createElement('li');
      li.textContent = `${todo.task} - ${formatDate(todo.dueDate)}`;
      const editButton = document.createElement('button');
      editButton.textContent = 'Edit';
      const deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      li.appendChild(editButton);
      li.appendChild(deleteButton);
      todoList.appendChild(li);
  });
  // Advanced: Full rendering with edit/delete functionality
}

// Handle form submission
document.getElementById("todoForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const task = document.getElementById("task").value;
  const dueDate = document.getElementById("dueDate").value;
  const completed = document.getElementById("completed").checked;

  // Simple: Add todo and clear form
  // await addTodo(task, dueDate, completed);
  // document.getElementById('todoForm').reset();

  // Medium: Add todo, clear form, refresh list
  await addTodo(task, dueDate, completed);
  document.getElementById('todoForm').reset();
  const todos = await fetchTodos();
  renderTodos(todos);

  // Advanced: Validate input, add todo, refresh list, clear form
});

// Edit todo handler
function editTodo(todoId, task, dueDate, completed) {
  // Simple: Prompt for new task
  // const newTask = prompt('Enter new task:', task);
  // if (newTask) updateTodo(todoId, newTask, dueDate, completed);
  // Medium: Prompt for task and date
  const newTask = prompt('Enter new task:', task);
  const newDueDate = prompt('Enter new due date (YYYY-MM-DD):', dueDate);
  if (newTask && newDueDate) updateTodo(todoId, newTask, newDueDate, completed);
  // Advanced: Prompt for all fields, validate, update
}

// Delete todo handler
async function deleteTodoHandler(todoId) {
  // Simple: Delete todo
  // await deleteTodo(todoId);
  // Medium: Delete and refresh
  await deleteTodo(todoId);
  const todos = await fetchTodos();
  renderTodos(todos);
  // Advanced: Confirm deletion, delete, refresh
}

// Initialize app
async function init() {
  // Simple: Fetch and render
  // const todos = await fetchTodos();
  // renderTodos(todos);
  // Medium: Fetch with basic error logging
  const todos = await fetchTodos();
  if (todos.length === 0) console.log('No todos found.');
  renderTodos(todos);
  // Advanced: Fetch with user feedback
}

init();








/*
usage: 
x,y are x and y coordinates on the viewport(you could get these in response to an onclick event, they
have .x and .y event properties that show where the mouse clicked)

particalLife is time in Milliseconds  before particle dissolves, i.e. 500 is 1/2 second.

particleSpeed is a smaller number multiplied by the speed.
e.g. 1.0 is normal speed, 2.0 is twice as face, 3.0 is three times as fast

particleAngleStart is the starting angle
particleAngleEnd is the ending angle
e.g. anywhere in a circle would be 0, and 360 for those two arguments respectively
e.g. anywhere in the left side of vertical would be 90, and 270 for those two arguments respectively
e.g. anywhere in the right side of vertical would be 270, and 90,  for those two arguments respectively


particleMinSize is the minimum div(particle) size in px.
particleMaxSize is the Maximum div(particle) size in px.
they are randomly generated between that range.
particleColor can be any valid CSS backgroundColor property, if left blank, its random


example usage: 

button.onclick = (event) => { 
     for (let i = 0; i < 30; i++) {
      particle(
        event.x,
        event.y,
        Math.random() * 100,
        Math.random() * 3,
        0,
        360,
        0,
        8,
        `hsl(300,${Math.random() * 100}%,${Math.random() * 100}%)`
      );
    }
  }
 
this will create 30 particles each button click event, centered at the 
button click of the mouse, 3 times normal speed, with a random life of up to 100milliseconds
0,360,  means shoot out anywhere in a circle from the center point.
of random sizes 0px to 8px in size

and that is 
`hsl(300,${Math.random() * 100}%,${Math.random() * 100}%)`
hsl(300,%,%) gives like a magenta, with random intensity and lightness
    
*/////////////////////////////////////////////////////////////////////////

// function particle(
//   x,
//   y,
//   particleLife,
//   particleSpeed,
//   particleAngleStart,
//   particleAngleEnd,
//   particleMinSize,
//   particleMaxSize,
//   particleColor
// ) {
//   let newParticle = document.createElement("div");
//   let size = `${(Math.random() * particleMaxSize) + particleMinSize}px`;
//   newParticle.style.width = size;
//   newParticle.style.height = size;
//   newParticle.style.borderRadius = "50%";
//   newParticle.style.backgroundColor = particleColor
//     ? particleColor
//     : `hsl(${Math.random() * 360},75%,75%)`;

//   newParticle.style.position = "absolute";
//   newParticle.x = x;
//   newParticle.y = y;
//   newParticle.style.left = `${newParticle.x}px`;
//   newParticle.style.top = `${newParticle.y}px`;
//   newParticle.style.zIndex = `10`;

//   document.body.appendChild(newParticle);
//   let timeOut = particleLife
//     ? particleLife + 1
//     : Math.floor(Math.random() * 250);
//   let randomDir = (Math.random() * (particleAngleEnd - particleAngleStart)) + particleAngleStart
    
//     randomDir *=  (Math.PI / 180) //convert to radians;
//   let vx = Math.cos(randomDir) * particleSpeed;
//   let vy = Math.sin(randomDir) * particleSpeed;
//   let movementInterval = setInterval(() => {
//     timeOut = timeOut - 1;
//     if (timeOut > 0) {
//       newParticle.x += vx;
//       newParticle.y += vy;
//       newParticle.style.left = `${newParticle.x}px`;
//       newParticle.style.top = `${newParticle.y}px`;
//     } else {
//       newParticle.parentElement.removeChild(newParticle);
//       clearInterval(movementInterval);
//     }
//   }, 10);
// }

